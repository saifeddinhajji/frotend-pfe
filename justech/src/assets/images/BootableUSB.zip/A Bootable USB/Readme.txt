Description:
============

"A Bootable USB" allows you to create bootable USB drive to install Windows Vista, Windows 7 and Windows Server 2008.


Homepage:
=========

http://www.askvg.com/a-bootable-usb-utility-to-create-bootable-usb-drive-to-install-windows-vista-server-2008-and-7/


Don't forget to visit AskVG.com for more freeware.

Copyright � AskVG.com. All rights reserved.

http://www.AskVG.com/